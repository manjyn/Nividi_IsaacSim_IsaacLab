from glob import glob
from setuptools import setup

name = 'mini_robot'
setup(
    name=name, version='0.1.0', packages=[name],
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + name]),
        ('share/' + name, ['package.xml']),
        ('share/' + name + '/launch', glob('launch/*.launch.py')),
        ('share/' + name + '/urdf', glob('urdf/*.urdf')),
    ],
    install_requires=['setuptools'], zip_safe=True,
    maintainer='Learner', maintainer_email='learner@example.com',
    description='Distance-based turtle controller', license='Apache-2.0',
    entry_points={'console_scripts': [
        'sensor = mini_robot.sensor:main',
        'guard = mini_robot.guard:main',
        'enable = mini_robot.enable_client:main',
        'turn = mini_robot.turn:main',
    ]},
)
