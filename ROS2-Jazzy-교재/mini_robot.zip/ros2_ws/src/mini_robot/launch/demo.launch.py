from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(package='turtlesim', executable='turtlesim_node'),
        Node(package='mini_robot', executable='sensor', output='screen'),
        Node(package='mini_robot', executable='guard', output='screen',
             parameters=[{'stop_distance': 1.0}]),
    ])
