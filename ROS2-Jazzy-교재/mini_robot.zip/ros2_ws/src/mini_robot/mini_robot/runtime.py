import rclpy
from rclpy.executors import ExternalShutdownException

def run(node_type):
    rclpy.init()
    node = node_type()
    try:
        rclpy.spin(node)  # 준비된 구독, 서비스, 타이머 콜백을 처리한다.
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
