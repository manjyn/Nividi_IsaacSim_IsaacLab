import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from turtlesim.action import RotateAbsolute

def main():
    rclpy.init()
    node = Node('turn_client')
    client = ActionClient(node, RotateAbsolute, 'turtle1/rotate_absolute')
    try:
        if not client.wait_for_server(timeout_sec=5.0):
            node.get_logger().error('회전 서버를 찾을 수 없습니다.')
            return
        goal = RotateAbsolute.Goal()
        goal.theta = 1.57  # 절대 방향, 라디안 단위
        def feedback(event):
            node.get_logger().info(f'남은 각도 {event.feedback.remaining:.2f}')
        sent = client.send_goal_async(goal, feedback_callback=feedback)
        rclpy.spin_until_future_complete(node, sent)
        handle = sent.result()
        if not handle.accepted:
            node.get_logger().warn('목표가 거절됐습니다.')
            return
        done = handle.get_result_async()
        rclpy.spin_until_future_complete(node, done)
        reply = done.result()
        node.get_logger().info(f'status={reply.status}, delta={reply.result.delta}')
    finally:
        client.destroy()
        node.destroy_node()
        rclpy.try_shutdown()
