from math import cos, sin
from rclpy.node import Node
from std_msgs.msg import Float32
from turtlesim.msg import Pose
from mini_robot.runtime import run

class WallSensor(Node):
    def __init__(self):
        super().__init__('wall_sensor')
        self.pub = self.create_publisher(Float32, 'clearance', 10)
        self.create_subscription(Pose, 'turtle1/pose', self.measure, 10)

    def measure(self, pose):
        # 한 변 11인 가상 구역에서 전방 광선과 벽의 교점을 구한다.
        hits = []
        for pos, direction in ((pose.x, cos(pose.theta)),
                               (pose.y, sin(pose.theta))):
            if abs(direction) > 1e-6:
                edge = 11.0 if direction > 0 else 0.0
                hits.append((edge - pos) / direction)
        distance = max(0.0, min(hits))
        self.pub.publish(Float32(data=distance))

def main():
    run(WallSensor)
