import rclpy
from rclpy.node import Node
from std_srvs.srv import SetBool

def main():
    rclpy.init()
    node = Node('enable_client')
    client = node.create_client(SetBool, 'enable_drive')
    try:
        if not client.wait_for_service(timeout_sec=5.0):
            node.get_logger().error('제어 서비스가 보이지 않습니다.')
            return
        request = SetBool.Request()
        request.data = True
        future = client.call_async(request)  # 응답 처리는 실행기에 맡긴다.
        rclpy.spin_until_future_complete(node, future, timeout_sec=3.0)
        if future.done():
            reply = future.result()
            node.get_logger().info(f'{reply.success}: {reply.message}')
        else:
            node.get_logger().warn('응답 시간 초과: 구동 상태를 확인하세요.')
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
