from math import isfinite
from time import monotonic
from geometry_msgs.msg import Twist
from rclpy.node import Node
from std_msgs.msg import Float32
from std_srvs.srv import SetBool
from mini_robot.runtime import run

class Guard(Node):
    def __init__(self):
        super().__init__('guard')
        self.declare_parameter('stop_distance', 1.0)
        self.enabled = False
        self.distance = 0.0
        self.seen = float('-inf')
        self.pub = self.create_publisher(Twist, 'turtle1/cmd_vel', 10)
        self.create_subscription(Float32, 'clearance', self.observe, 10)
        self.create_service(SetBool, 'enable_drive', self.enable)
        self.create_timer(0.1, self.drive)

    def observe(self, msg):
        self.distance = msg.data
        self.seen = monotonic()  # 수신 후 경과 시간만 비교한다.

    def enable(self, req, res):
        self.enabled = req.data
        res.success = True
        res.message = 'enabled' if self.enabled else 'disabled'
        self.get_logger().info(res.message)
        return res

    def drive(self):
        limit = self.get_parameter('stop_distance').value
        cmd = Twist()  # 조건 하나라도 실패하면 영속도다.
        if (self.enabled and monotonic() - self.seen < 0.5
                and isfinite(self.distance) and isfinite(limit)
                and limit > 0 and self.distance > limit):
            cmd.linear.x = 0.8
        self.pub.publish(cmd)

def main():
    run(Guard)
